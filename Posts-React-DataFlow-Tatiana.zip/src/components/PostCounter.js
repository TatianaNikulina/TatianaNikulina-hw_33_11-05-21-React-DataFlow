import React from "react";

export default ({
  id,
  likeCounter,
  dislikeCounter,
  sum,
  likeHandle,
  dislikeHandle,
  calcSum,
}) => {
  return (
    <div>
      <button onClick={() => likeHandle(id)}>Like "+"</button>
      <span>{likeCounter}</span>
      <button onClick={() => dislikeHandle(id)}>Dislike "-"</button>
      <span>{dislikeCounter}</span>
      <button onClick={() => calcSum(id)}>Рейтинг</button>
      <span>{sum}</span>
    </div>
  );
};
